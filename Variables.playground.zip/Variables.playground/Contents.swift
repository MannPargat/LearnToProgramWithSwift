import UIKit

// there are two things variables and constants

//this is variable which is Integer
var myAge = 22

//you can also write this like
var myGirlfrinedsAge : Int = 22
//wandering why i didn't wrote 'myAge', good because that name or better to say that variable name is already used, didn't belive me good try yourself.

//this is constant of type String
let myDOB = "13-05-1996"

//you can also write it like this
let myGirlfrinedsDOB : String = "13-05-1996"

//now you must be thinking what is type, which i have just mention above if not good that why i'm here.

//there are four main datatypes or aka 'type' Integers, Floats, Strings, Boolean. You can think of it as boxes which will hold only one type of data that you define.
var iAmInteger = 1
var iAmFloat = 1.2
var iAmString = "Hi Guys"
var iAmBoolean = true

//there are also some subcatagory but those are not that important right now.

//one cool way to declare variable or constants
var myFirstGF = "Emma" , mySecondGF = "Jennifer" , myThirdGF🙈 = "kim"

//you can do the same with all the four type's and with constants also and yes you can also use emoji's as well.


// now after variables, constants and datatype it's time to learn about 'Tuples'

let locationOfMyGF = (41.40338, 2.17403)

//we can also write it as
let locationOfMySecondGF = (Double(41.40338), Double(2.17403))

//oops, i should hide samewhere (same location)

//some more examples of 'Tuples'
let httpError404 = (404, "Not found")

//we can access them with dot operator
httpError404.0

//'Tuples' is commonly used to pass values around

//Optionals
let myGFsCount : Int? = nil

if myGFsCount != nil {
    print("🙈 oops")
}else{
    print("he is a good man 😇")
}










